import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  template: `
    <toh-hero></toh-hero>
    <admin-users></admin-users>
  `
})
export class AppComponent { }
