export * from './hero-list.component';
