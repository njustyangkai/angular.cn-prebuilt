/* avoid */

export interface IHero {
  name: string;
  power: string;
}

export class Hero implements IHero {
  name: string;
  power: string;
}
