import { Injectable } from '@angular/core';

@Injectable()
export class ExceptionService {
  constructor() { }
  // testing harness
  getException() { return 42; }
}
