import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  template: '<toh-hero-button label="OK"></toh-hero-button>'
})
export class AppComponent { }
