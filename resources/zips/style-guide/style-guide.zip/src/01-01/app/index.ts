export * from './heroes';
export * from './app.component';
